package q1;

public interface Operations {
	public void insertData();
	public void deleteData();
	public void updateData();
	public void showData();
	public void searchData();
}
