package q1;

import java.util.ArrayList;
import java.util.List;

public class OprImp implements Operations {
	List<Emp> db = new ArrayList<Emp>();
	@Override
	public void insertData() {
		
	}

	@Override
	public void deleteData() {
		
	}

	@Override
	public void updateData() {
		
	}

	@Override
	public void showData() {
		
	}

	@Override
	public void searchData() {
		
	}

}
